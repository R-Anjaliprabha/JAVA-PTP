import java.util.Scanner;
class Quardatic{
  public static void main(String...args){
   Scanner sc = new Scanner(System.in);
   int a = sc.nextInt();
   int b = sc.nextInt();
   int c = sc.nextInt();

   Double x=Math.sqrt(b*b-4*a*c);

     if(x>0){
       System.out.println( (-b+x) /2*a);
       System.out.println( (-b-x) /2*a);
     }else{
        System.out.println("Roots are equal");
      }
  }
}