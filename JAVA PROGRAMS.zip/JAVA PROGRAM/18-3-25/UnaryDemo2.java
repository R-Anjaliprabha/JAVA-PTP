class UnaryDemo2{
  public static void main(String[]args){
    //Pre Decrement
    int a=10;
    System.out.println("Pre Inc: "+(--a+a));
    //Post Decrement
    a=10;
    System.out.println("Post Inc: "+(a--+a));
    a=10;
    System.out.println("Sum is: "+Integer.sum(--a,a));
  }
}