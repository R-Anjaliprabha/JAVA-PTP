class UnaryDemo{
  public static void main(String[]args){
    //Pre Increment
    int a=10;
    System.out.println("Pre Inc: "+(++a+a));
    //Post Increment
    a=10;
    System.out.println("Post Inc: "+(a+++a));
    a=10;
    System.out.println("Sum is: "+Integer.sum(++a,a));
  }
}