public class Relational{
 public static void main(String[]args){
  int a=5; 
  int b=10;
  System.out.println("Greater than: "+(a>b));
  System.out.println("Less than: "+(a<b));
  System.out.println("Greater than or equal to: "+(a>=b));
  System.out.println("Less than or equal to: "+(a<=b));
  System.out.println("Is Equal to: "+(a==b));
  System.out.println("Not Equal to: "+(a!=b));
 }
}