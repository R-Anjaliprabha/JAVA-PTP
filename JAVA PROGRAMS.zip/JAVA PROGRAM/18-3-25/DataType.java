import java.util.*;
  public class DataType{
    public static void main(String[]args){
       Scanner sc = new Scanner(System.in);
       int i = sc.nextInt();
       Double d = sc.nextDouble();
       sc.nextLine();
       String str = sc.nextLine();

       System.out.println("string: "+str);
       System.out.println("Double: "+d);
       System.out.println("Int: "+i);

    }
  }