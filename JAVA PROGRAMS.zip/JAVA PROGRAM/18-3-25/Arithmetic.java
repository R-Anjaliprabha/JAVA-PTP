import java.util.*;
 public class Arithmetic{
  public static void main(String[]args){
   Scanner sc=new Scanner(System.in);
   int a=sc.nextInt();
   int b=sc.nextInt();
   
   System.out.println("Sum is: "+(a+b));
   System.out.println("Diff is: "+(a-b));
   System.out.println("Product is: "+(a*b));
   System.out.println("Division is: "+(a/b));
   System.out.println("Modulus is: "+(a%b)); 
  }
 }