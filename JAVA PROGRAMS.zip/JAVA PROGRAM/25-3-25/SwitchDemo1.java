import java.util.Scanner;

class SwitchDemo1{
  public static void main(String...args){
    Scanner sc = new Scanner(System.in);
    System.out.println("Choose any one process for calculation:\n1.Addition\n2.Subtraction");
    System.out.println("------Select what you Want Me To Calculate-----");
    int x = sc.nextInt();
    int a, b;
    System.out.println("Enter 2 values: ");
              a = sc.nextInt();
              b = sc.nextInt();
    int result = Switch(exp){
           case 1 -> a+b;
           case 2 -> a-b;
           default -> 0;
     System.out.println("The End Result is: " +result);
     };
  }     
}