import java.util.Scanner;

class Switch1{
  public static void main(String...args){
    Scanner sc = new Scanner(System.in);
    while(true){

    System.out.println("Choose any one process for calculation:\n1.Addition\n2.Subtraction\n3.Multiplication\n4.Division\n5.Exit");
    int x = sc.nextInt();
    int a, b;
    System.out.println("Enter 2 values: ");
              a = sc.nextInt();
              b = sc.nextInt();

     switch(x){
       case 1:
              System.out.println("Addition is " +(a+b));
              break;
       case 2:
              System.out.println("Subtraction is " +(a-b));
              break;   
       case 3: 
              System.out.println("Multiplication is " +(a*b));
              break;
       case 4:
              System.out.println("division is " +(a/b));
              break;
       default:
              System.out.println("Thank you!!");
      }
    }  
  }
}