import java.util.Scanner;

class SwitchDemo{
  public static vid main(String...args){
    Scanner sc = new Scanner(System.in);
    int val = sc.nextInt();
    switch(val){
          case 1:
          case 2:
          case 3:
          case 4: System.out.println(val);
                  break;
          default: 
                  System.out.println("Default");
    }
  }
}