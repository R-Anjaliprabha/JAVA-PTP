import java.util.Scanner;
class Sort{
	public static void main(String...args){
		Scanner s = new Scanner(System.in);
		int size = s.nextInt();
		int [] a = new int[size];
		int he = 0;

  	 	for(int i=0; i<size; i++)
			a[i] = s.nextInt();
		for(int x : a)
			System.out.print(x + " ");
		for(int i=0; i<a.length; i++){
			int e = a[i];
			if(he < e)
				he = e;
			for (i = 0; i < a.length - 1; i++) {
   				 for (int j = 0; j < a.length - 1 - i; j++) {
        				if (a[j] > a[j + 1]) {
            				he = a[j];
           				a[j] = a[j + 1];
            				a[j + 1] = he;
                            
        			 }
    		  	}
		}
		}
		System.out.println(" ");
		for(int x : a)

			System.out.print(x + " ");

	}
}


