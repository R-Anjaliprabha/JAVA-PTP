import java.util.Scanner;
class RemoveArray{
	public static void main(String...args){
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		int arr[] = new int [n];
		int value = s.nextInt();
		Str integervalue = NULL;
		for(int i=0; i<n; i++)
			arr[i] = s.nextInt();
		for(int i=0; i<=arr.length; i++){
			if(value == arr[i]){
				arr[i] = integervalue;
				break;
			}
		}
		for(int i : arr)
			System.out.print(i+" ");
		System.out.println("");		
		
	}
}