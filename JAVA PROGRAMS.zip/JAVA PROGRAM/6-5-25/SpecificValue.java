import java.util.Scanner;
class SpecificValue{
	public static void main(String...args){
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		int arr[] = new int [n];
		int flag = 0;
		int value = s.nextInt();
		for(int i=0; i<n; i++)
			arr[i] = s.nextInt();
		for(int i=0; i<=arr.length; i++){
			if(value == arr[i]){
				System.out.println("FOUND at : "+flag);
				flag = i;
				break;
			}
		}
		if (flag == 0){
			System.out.println("NOT FOUND");
		}
	}
}