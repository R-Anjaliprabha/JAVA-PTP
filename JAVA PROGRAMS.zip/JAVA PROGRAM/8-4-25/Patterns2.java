import java.util.Scanner;
 class Patterns2{
  public static void main(String[]args){
    Scanner sc = new Scanner(System.in);
    int x = sc.nextInt();
    
    for(int i=0; i<x; i++){
        System.out.print("* ");
	System.out.println("*");
    }

  }
 }